# Tower of Annihilation
CS 383 - Tower of Annihilation - Room 4 Studios
## Quick Launch
- Click the green `Code` button to open the dropdown.
- Click `Download ZIP` and download it somewhere you can easily access it.
- Once downloaded, uncompress the file.
- Click `Tower-of-Annihilation.exe` to get the game running on windows.
    - The game is set to 1920x1080 but will scale down with smaller monitors.
- Pressing `ESC` will open the games menu.
    - `RESUME` : Unpauses the game right where it was left off.
    - `EXIT` : Closes the game.
    - `OPTIONS` : Opens the options manager.
    - `MENU` : Returns you to the games main menu.
    - Player:
        - Player 1: 
            - Up: `W`
            - Down: `S`
            - Left: `A`
            - Right: `D`
            - Attack: `SpaceBar`
            - Pause: `Esc`
